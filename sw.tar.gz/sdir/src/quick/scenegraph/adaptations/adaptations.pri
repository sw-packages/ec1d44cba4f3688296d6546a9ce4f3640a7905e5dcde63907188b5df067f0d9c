include(software/software.pri)
